module Main where

import           Codec.Wav          (exportFile, importFile)
import           Data.Array.Unboxed (elems, listArray)
import           Data.Audio         (Audio (Audio))
import           Data.Int           (Int32)
import           Data.Maybe         (fromMaybe)
import           System.IO          (FilePath)

import           Graphics.Gloss
file = "flutec.wav"

inMain :: FilePath -> IO ()
inMain path = do
    maybeAudio <- importFile path
    case maybeAudio :: Either String (Audio Int32) of
        Left s -> putStrLn $ "wav decoding error: " ++ s
        Right (Audio rate channels samples) -> do
            putStrLn $ "rate = " ++ show rate
            putStrLn $ "channels: " ++ show channels
            print $ elems samples

main :: IO ()
main = do
    display (InWindow "Nice Window" (200, 200) (10, 10)) white (Circle 80)
    -- putStrLn $ "* Printing the content of " ++ file
    -- -- print all the samples in the file
    -- inMain file
